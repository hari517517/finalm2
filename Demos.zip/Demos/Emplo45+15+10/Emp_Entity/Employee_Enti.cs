﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emp_Entity
{
    [Serializable]
    public class Employee_Enti
    {
        public int Emp_Id { get; set; }
        public string Emp_Name { get; set; }
        public double Emp_Salary { get; set; }
        public DateTime Emp_DOJ { get; set; }

    }
}
