﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace customer
{
    class customer
    {
        //Creating properties for customer 
        public int BillNo { get; set; }
        public int CustomerID { get; set; }
        public string  CustomerName { get; set; }
        public string MobileNo { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public int UnitsConsumed { get; set; }
        public int Rate { get; set; }       
        public double Amount { get;  set ;  }        
        public double SurCharge { get ;  set;  }       
        public double GrossAmount { get ;  set ; }

    }
}
