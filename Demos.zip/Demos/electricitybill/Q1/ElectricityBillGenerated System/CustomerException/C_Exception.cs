﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerException
{
    //In this layer if any exception occur throughout the layer structure will be handeled.
    [Serializable]
    public class C_Exception : Exception
    {
        public C_Exception() { }
        public C_Exception(string message) : base(message) { }
        public C_Exception(string message, Exception inner) : base(message, inner) { }
        protected C_Exception(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
