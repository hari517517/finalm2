﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Emp_Entity;
using Emp_Exception;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Emp_DAL
{
    public class Employee_DAL
    {
        public static List<Employee_Enti> emp = new List<Employee_Enti>();
      

        public bool AddEmployeeDAL(Employee_Enti employee)
        {
            bool employeeAdded = false;
            try
            {
                emp.Add(employee);
                employeeAdded = true;

            }
            catch (Exception ex1)
            {

                throw ex1;
            }
            return employeeAdded; 
        }
        public Employee_Enti DisplayEmployeeDAL(int empid)
        {
            try
            {
                Employee_Enti displayEmployee = null;
                foreach(var employee in emp)
                {
                    if(employee.Emp_Id== empid)
                    {
                        displayEmployee = employee;
                    }
                }
                return displayEmployee;
            }
            catch (Exception ex2)
            {

                throw ex2;
            }
        }
        public static void SerializaData()
        {
            FileStream stream;
            try
            {
                stream = new FileStream(@"Employee.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, emp);
                stream.Close();
            }
            catch (Exception e)
            {

                throw e;
            }
        }
        public static List<Employee_Enti> Deserilization()
        {
            FileStream stream = new FileStream(@"Employee.txt", FileMode.Open, FileAccess.Read);
            BinaryFormatter formatter = new BinaryFormatter();
            emp = formatter.Deserialize(stream) as List<Employee_Enti>;
            return emp;
        }
    }
}
