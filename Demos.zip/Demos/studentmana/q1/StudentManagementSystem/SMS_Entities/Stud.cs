﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Emp Id:172322
 * Author Name: Susmitha
 * Creation Date:12/02/2019
*/
namespace SMS_Entities
{
    [Serializable]
    public class Student
    {
        //Creating the property fields for the following
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public string CourseName { get; set; }
        public char Grade { get; set; }
    }
}
