﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Emp Id:172322
 * Author Name: Susmitha
 * Creation Date:12/02/2019
*/

namespace SMS_Exceptions
{
    
        [Serializable]
        public class StudentNotFoundException : Exception
        {
            //creating the exceptions if the student information is not valid then exception is thrown
            public StudentNotFoundException() { }
            public StudentNotFoundException(string message) : base(message) { }
            public StudentNotFoundException(string message, Exception inner) : base(message, inner) { }
            //protected StudentNotFoundException(
            //  System.Runtime.Serialization.SerializationInfo info,
            //  System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
        }
    
}
