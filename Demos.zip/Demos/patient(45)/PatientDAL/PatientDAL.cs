﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using PatientEntity;
using HMSException;

namespace PatientDAL
{  /* class List1<T>
     {
         List<T> list = new List<T>();
         public T this[int index]
         {
             get { return list[index]}
             set{list.a}
         }

     }
    */
    public class PatientDAL
    {
        static List<Patient> patientList = new List<Patient>();
        public bool AddPatientDAL(Patient newPatient)
        {
            bool patinetAdded = false;
            try
            {

                patientList.Add(newPatient);
                patinetAdded = true;


            }
            catch (Exception ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }
            return patinetAdded;

        }

        public List<Patient> GetAllPatientsDAL()
        {
            return patientList;
        }

        public bool DeletePatientDAL(int deletepatientID)
        {
            bool patientDeleted = false;
            try
            {
                for (int i = 0; i < patientList.Count; i++)
                {
                    Patient patient = patientList[i];
                    if (patient.PatientID == deletepatientID)
                    {
                        patientList.RemoveAt(i);
                        patientDeleted = true;
                        break;
                    }
                }

            }
            catch (Exception ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }
            return patientDeleted;

        }


        public Patient SearchPatientDAL(int searchPatientID)
        {
            Patient searchPatient = null;
            try
            {


                for (int i = 0; i < patientList.Count; i++)
                {
                    Patient patient = patientList[i];
                    if (patient.PatientID == searchPatientID)
                    {
                        searchPatient = patientList[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }
            return searchPatient;
        }

        public bool UpdatePatientDAL(Patient updatePatient)
        {
            bool patientUpdated = false;
            try
            {


                for (int i = 0; i < patientList.Count; i++)
                {
                    Patient patient = patientList[i];
                    if (patient.PatientID == updatePatient.PatientID)
                    {
                        patientList[i] = updatePatient;
                        break;
                    }
                }

                patientUpdated = true;
            }
            catch (Exception ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }
            return patientUpdated;

        }

    }
}
