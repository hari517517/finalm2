﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using PatientEntity;
using PatientBLL;

namespace PatientPL
{
    class Program
    {
        static void Main(string[] args)
        {
            /*  Patient pat = new Patient();
              pat.patientId = 4545;
              pat.patientName = "Rohan";

              Console.WriteLine("The Id is:" + pat.patientId);
              Console.WriteLine("The Name is:" + pat.patientName);
              Console.ReadLine();*/
            Attribute[] attr = Attribute.GetCustomAttributes(typeof(Patient));
            GenderAttribute gen = (GenderAttribute)attr[0];
            Console.WriteLine("{0}",gen.Gender);
            //public bool isEmpty()
            //{
            //var properties = typeof(Patient).GetProperties();
            //foreach (var prop in properties)
            //{ 
            //    var value=prop.GetValue(this,null);
            //    if(value!=null && (string)value!="")
            //    {
            //        return false;
            //    }
                
            //}
               //return true;
            //}
            

            PrintMenu();

        }


        private static void PrintMenu()
        {
            string choice1;
            do
            {
                Console.WriteLine("\n***********Hospital Management System ***********");
                Console.WriteLine("1. Add Patient");
                Console.WriteLine("2. Delete Patient");
                Console.WriteLine("3. Get all Patient Details");
                Console.WriteLine("4. Search Patient");
                Console.WriteLine("5. Update Patient");

                int choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddPatient();
                        break;
                    case 2:
                        DeletePatient();
                        break;
                    case 3:
                        ListAllPatients();
                        break;
                    case 4:
                        SearchPatientByID();
                        break;
                    case 5:
                        UpdatePatient();
                        break;

                }
                Console.WriteLine("Do you want to contiue(y/n)?");
                choice1 = Console.ReadLine();
            } while ((choice1 == "y"));
            Console.Read();


        }


        private static void AddPatient()
        {
            try
            {
                Patient newPatient = new Patient();
               
                
             

                Console.WriteLine("Enter Patient ID :");
                newPatient.PatientID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Patient Name :");
                newPatient.PatientName = Console.ReadLine();
                Console.WriteLine("Enter PhoneNumber :");
                newPatient.Phone = Console.ReadLine();
                
               
               
                bool patientAdded = PatientBLL.PatientBLL.AddPatientBL(newPatient);
                if (patientAdded)
                    Console.WriteLine("Patient Added");
                else
                    Console.WriteLine("Patient not Added");
            }
            catch (HMSException.HMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ListAllPatients()
        {
            try
            {
                List<Patient> patientList = PatientBLL.PatientBLL.GetAllPatientsBL();
                if (patientList != null && patientList.Count > 0)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("PatientID\t\tName\t\tPhoneNumber");
                    Console.WriteLine("******************************************************************************");
                    foreach (Patient patient in patientList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}", patient.PatientID, patient.PatientName, patient.Phone);
                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Patient Details Available");
                }
            }
            catch (HMSException.HMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdatePatient()
        {
            try
            {
                int updatePatientID;
                Console.WriteLine("Enter PatientID to Update Details:");
                updatePatientID = Convert.ToInt32(Console.ReadLine());
                Patient updatedPatient = PatientBLL.PatientBLL.SearchPatientBL(updatePatientID);
                if (updatedPatient != null)
                {
                    Console.WriteLine("Update Patient Name :");
                    updatedPatient.PatientName = Console.ReadLine();
                    Console.WriteLine("Update PhoneNumber :");
                    updatedPatient.Phone = Console.ReadLine();
                    bool patientUpdated = PatientBLL.PatientBLL.UpdatePatientBL(updatedPatient);
                    if (patientUpdated)
                        Console.WriteLine("Patient Details Updated");
                    else
                        Console.WriteLine("Patient Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Patient Details Available");
                }


            }
            catch (HMSException.HMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchPatientByID()
        {
            try
            {
                int searchPatientID;
                Console.WriteLine("Enter PatientID to Search:");
                searchPatientID = Convert.ToInt32(Console.ReadLine());
                Patient searchPatient = PatientBLL.PatientBLL.SearchPatientBL(searchPatientID);
                if (searchPatient != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("PatientID\t\tName\t\tPhoneNumber");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}", searchPatient.PatientID, searchPatient.PatientName, searchPatient.Phone);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Patient Details Available");
                }

            }
            catch (HMSException.HMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeletePatient()
        {
            try
            {
                int deletePatientID;
                Console.WriteLine("Enter PatientID to Delete:");
                deletePatientID = Convert.ToInt32(Console.ReadLine());
                bool patientdeleted = PatientBLL.PatientBLL.DeletePatientBL(deletePatientID);
                if (patientdeleted)
                    Console.WriteLine("Patient Deleted");
                else
                    Console.WriteLine("Patient not Deleted ");


            }
            catch (HMSException.HMSException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

    }
}
