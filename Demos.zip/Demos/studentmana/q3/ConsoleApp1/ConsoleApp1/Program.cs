﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*Emp Id:172322
 * Author Name: Susmitha
 * Creation Date:12/02/2019
*/
// Accepting a name of file from user and displaying the details of it


namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            try

            {
                //creating the file path
                FileInfo fileObj1 = new FileInfo(@"C:\Users\sbojjaga\Desktop\Questions\q3\ConsoleApp1\susmitha.txt");

                if (fileObj1.Exists)

                {
                    //getting the file name
                    Console.WriteLine("File Name = {0}", fileObj1.Name);
                    //getting the length of the file
                    Console.WriteLine("File length in Bytes = {0}", fileObj1.Length);

                    Console.WriteLine("File Extension = {0}", fileObj1.Extension);
                    //getting the file extension
                    Console.WriteLine("File Full path = {0}", fileObj1.FullName);
                    //getting the directory path
                    Console.WriteLine("File Directory = {0}", fileObj1.DirectoryName);

                    Console.WriteLine("File Parent Directory = {0}", fileObj1.Directory);
                    //getting the creation time of file
                    Console.WriteLine("File Creation Date and Time = {0}", fileObj1.CreationTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    //getting the last write time of file
                    Console.WriteLine("File Modified Date and Time = {0}", fileObj1.LastWriteTime.ToString("dd-MM-yyyy hh:mm:ss tt"));

                    Console.WriteLine("File Last Access Date and Time = {0}", fileObj1.LastAccessTime.ToString("dd-MM-yyyy hh:mm:ss tt"));

                    Console.WriteLine("File Attributes = {0}", fileObj1.Attributes.ToString());

                }

                else

                {

                    Console.WriteLine("File does not Exists");

                }

            }

            catch (Exception ex)

            {

                Console.WriteLine(ex.Message);

            }

            Console.ReadKey();

        }

    }
}
