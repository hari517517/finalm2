﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Emp_Entity;
using Emp_Exception;
using Emp_BAL;
using Emp_DAL;


namespace Emp_Presentation
{
    class Program
    {
        static int eid;
        public static void AddEmployee()
        {
            try
            {
                Employee_Enti e = new Employee_Enti();
                Console.WriteLine("enter the employee iD");
                e.Emp_Id = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter the employee name:");
                e.Emp_Name = Console.ReadLine();
                Console.WriteLine("enter the employee salary:");
                e.Emp_Salary = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("enter the employee date of joininig:");
                e.Emp_DOJ = DateTime.Parse(Console.ReadLine());
                bool employeeAdded = Employee_BAL.AddEmployeeBAL(e);
                if (employeeAdded == true)
                {
                    Console.WriteLine("employee added suc");
                }
                else
                {
                    throw new EmployeeNotFoundException("employee not added");
                }
                Employee_BAL.SerializaData();
            }
            catch (EmployeeNotFoundException e)
            {

                Console.WriteLine(e.Message);
            }
        }
        public static void DisplayEmployee()
        {
            int empid1;

            Employee_Enti displayEmployee;
            try
            {


                Console.WriteLine("enter employee id to diplay");
                empid1 = Convert.ToInt32(Console.ReadLine());
                displayEmployee = Employee_BAL.DisplayEmployeeBAL(empid1);
                if (displayEmployee != null)
                {
                    Console.WriteLine($"employee id:{displayEmployee.Emp_Id},employee name:{displayEmployee.Emp_Name},employee salary:{displayEmployee.Emp_Salary},emnployeedoj:{displayEmployee.Emp_DOJ}");
                }
                else
                {
                    throw new EmployeeNotFoundException("employee not found");
                }
            }
            catch (Exception e2)
            {

                Console.WriteLine(e2.Message);
            }
        }
        public static void EmpMenu()
        {
            string userChoice;
            do
            {
                Console.WriteLine("===========Employee menu Details==========");
                Console.WriteLine("1. for add details");
                Console.WriteLine("2 for see the employtee details");
                Console.WriteLine("enter your choice ");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1: AddEmployee(); break;
                    case 2: DisplayEmployee(); break;
                    default: Console.WriteLine("plese provide valid choice 1 or 2"); break;
                }
                Console.WriteLine("if you want to continue plese press y or n?");
                userChoice = Console.ReadLine();


            }
            while (userChoice != "n");

        }
        static void Main(string[] args)
        {

            EmpMenu();
            Console.ReadKey();
        }
    }
}
